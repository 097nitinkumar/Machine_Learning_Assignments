function delJ_delTheta0 = theta0(X, y, theta)
%returns del(J)/del(theta0)
% Initialize some useful values
n = length(y); % number of training examples

% You need to return the following variables correctly 
delJ_delTheta0 = 0;
x=X(:,2);
% ====================== YOUR CODE HERE ======================
h=sum(((theta').*X)')';
delJ_delTheta0=(sum(-2*(y-h)))/(n);
% =========================================================================

end
